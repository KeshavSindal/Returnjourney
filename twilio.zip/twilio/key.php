<?php
$sid_key=""; // your sid key
$token_key=""; //your token key
$number="+91..." //your verified no with country code


?>